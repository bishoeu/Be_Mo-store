
import mongoose from 'mongoose';
const OrderSchema = new mongoose.Schema({
  merchant_order_id: String,
  paymob_order_id: String,
  amount_cents: Number,
  currency: String,
  status: String,
  payment_method: String,
  billing_data: Object,
  items: Array,
  createdAt: { type: Date, default: Date.now }
});
export default mongoose.models.Order || mongoose.model('Order', OrderSchema);
