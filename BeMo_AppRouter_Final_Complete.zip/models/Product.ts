
import mongoose from 'mongoose';
const ProductSchema = new mongoose.Schema({
  title: String,
  slug: { type: String, unique: true },
  price_cents: Number,
  description: String,
  images: [String],
  createdAt: { type: Date, default: Date.now }
});
export default mongoose.models.Product || mongoose.model('Product', ProductSchema);
