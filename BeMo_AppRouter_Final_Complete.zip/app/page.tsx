
import Link from 'next/link';
export default function Page(){
  return (
    <div className="container" style={{paddingTop:24}}>
      <h1>BeMoStore</h1>
      <p>قالب جاهز للنشر على Vercel مع تكامل دفع وإدارة منتجات.</p>
      <p><Link href="/products"><a className="btn">عرض المنتجات</a></Link></p>
    </div>
  )
}
