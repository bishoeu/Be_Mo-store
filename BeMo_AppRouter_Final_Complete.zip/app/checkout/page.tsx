
'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
export default function Page(){
  const router = useRouter();
  const [name,setName]=useState(''); const [phone,setPhone]=useState(''); const [method,setMethod]=useState('cod');
  async function place(e){
    e.preventDefault();
    const payload = { merchant_order_id: 'mo_' + Date.now(), amount_cents: 49900, currency:'EGP', billing_data:{name,phone}, items:[{title:'Demo',price_cents:49900}], payment_method: method };
    const res = await fetch('/api/orders/create', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
    const data = await res.json();
    if(res.ok){
      if(data.payment_url){ window.location.href = data.payment_url; return; }
      router.push('/success');
    } else {
      alert('خطأ: ' + (data.error||'خطأ غير معروف'));
    }
  }
  return (
    <div className="container" style={{paddingTop:24}}>
      <h1>الدفع</h1>
      <form onSubmit={place} style={{display:'flex',flexDirection:'column',gap:12,maxWidth:420}}>
        <input placeholder="الاسم" value={name} onChange={e=>setName(e.target.value)} />
        <input placeholder="الهاتف" value={phone} onChange={e=>setPhone(e.target.value)} />
        <div>
          <label><input type="radio" name="pay" value="cod" checked={method==='cod'} onChange={()=>setMethod('cod')} /> الدفع عند الاستلام</label>
          <label style={{marginLeft:12}}><input type="radio" name="pay" value="online" checked={method==='online'} onChange={()=>setMethod('online')} /> الدفع أونلاين</label>
        </div>
        <button className="btn" type="submit">تأكيد</button>
      </form>
    </div>
  )
}
