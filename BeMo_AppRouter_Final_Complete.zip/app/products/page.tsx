
import Link from 'next/link';
export default async function Page(){
  const base = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000';
  const res = await fetch(base + '/api/products/list');
  const products = await res.json().catch(()=>[]);
  return (
    <div className="container" style={{paddingTop:24}}>
      <h1>المنتجات</h1>
      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(240px,1fr))',gap:16,marginTop:16}}>
        {products.map((p:any)=>(
          <div key={p._id} className="card">
            <img src={p.images?.[0]||'/assets/product.jpg'} style={{width:'100%',height:160,objectFit:'cover',borderRadius:8}}/>
            <h3>{p.title}</h3>
            <p style={{fontWeight:700}}>{(p.price_cents/100).toFixed(2)} EGP</p>
            <a className="btn" href={`/products/${p.slug}`}>عرض</a>
          </div>
        ))}
      </div>
    </div>
  )
}
