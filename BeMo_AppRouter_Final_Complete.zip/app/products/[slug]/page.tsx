
import { notFound } from 'next/navigation';
export default async function Page({ params }:{ params:{ slug:string } }){
  const base = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000';
  const res = await fetch(base + '/api/products/list');
  const list = await res.json().catch(()=>[]);
  const product = list.find((p:any)=>p.slug === params.slug);
  if(!product) notFound();
  return (
    <div className="container" style={{paddingTop:24}}>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:20}}>
        <div><img src={product.images?.[0]||'/assets/product.jpg'} style={{width:'100%',borderRadius:8}}/></div>
        <div>
          <h1>{product.title}</h1>
          <p style={{fontWeight:700, fontSize:20}}>{(product.price_cents/100).toFixed(2)} EGP</p>
          <p>{product.description}</p>
          <a className="btn" href={`/checkout?product=${product.slug}`}>اشتري الآن</a>
        </div>
      </div>
    </div>
  )
}
