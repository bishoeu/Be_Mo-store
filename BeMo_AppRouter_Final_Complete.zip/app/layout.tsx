
import './globals.css'
export const metadata = { title: 'BeMoStore', description: 'BeMoStore — متجر إلكتروني جاهز' }
export default function RootLayout({ children }:{ children: React.ReactNode }){
  return (
    <html lang="ar" dir="rtl">
      <body>
        <header className="site-header">
          <div className="container header-inner">
            <a href="/" className="brand">BeMoStore</a>
            <nav className="nav">
              <a href="/products">المنتجات</a>
              <a href="/admin">لوحة المدير</a>
            </nav>
          </div>
        </header>
        <main>{children}</main>
        <footer className="site-footer">
          <div className="container">© 2025 BeMoStore</div>
        </footer>
      </body>
    </html>
  )
}
