
'use client';
import { useState, useEffect } from 'react';
export default function Page(){
  const [pass,setPass]=useState(''); const [authed,setAuthed]=useState(false); const [orders,setOrders]=useState([]);
  useEffect(()=>{ if(sessionStorage.getItem('admin_auth') === process.env.NEXT_PUBLIC_ADMIN_PASS) { setAuthed(true); fetchOrders(); } },[]);
  async function login(e){ e.preventDefault(); if(pass===process.env.NEXT_PUBLIC_ADMIN_PASS){ sessionStorage.setItem('admin_auth',pass); setAuthed(true); fetchOrders(); } else alert('كلمة مرور خاطئة'); }
  async function fetchOrders(){ const r=await fetch('/api/orders/list'); const d=await r.json(); setOrders(d); }
  if(!authed) return (<div className="container" style={{paddingTop:24}}><h1>تسجيل دخول المدير</h1><form onSubmit={login}><input placeholder="كلمة المرور" value={pass} onChange={e=>setPass(e.target.value)} /><button className="btn">دخول</button></form></div>);
  return (<div className="container" style={{paddingTop:24}}><h1>لوحة المدير</h1><button className="btn" onClick={fetchOrders}>تحديث</button><ul>{orders.map(o=>(<li key={o._id}>{o.merchant_order_id} - {o.status}</li>))}</ul></div>);
}
