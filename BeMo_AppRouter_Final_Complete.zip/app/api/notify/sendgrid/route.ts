
import { NextResponse } from 'next/server';
export async function POST(req: Request){
  const body = await req.json();
  const { to, subject, text, html } = body;
  const key = process.env.SENDGRID_API_KEY;
  if(!key) return NextResponse.json({ error:'sendgrid not configured' }, { status:500 });
  const payload = { personalizations:[{to:[{email:to}]}], from:{email: process.env.SENDGRID_FROM || 'no-reply@example.com'}, subject, content:[{type:'text/plain',value:text||''},{type:'text/html',value:html||''}] };
  const r = await fetch('https://api.sendgrid.com/v3/mail/send', { method:'POST', headers:{ 'Authorization':'Bearer ' + key, 'Content-Type':'application/json' }, body: JSON.stringify(payload) });
  if(r.status >= 400) return NextResponse.json({ error:'sendgrid failed' }, { status:500 });
  return NextResponse.json({ ok:true });
}
