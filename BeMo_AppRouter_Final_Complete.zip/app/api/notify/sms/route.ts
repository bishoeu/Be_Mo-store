
import { NextResponse } from 'next/server';
export async function POST(req: Request){
  const body = await req.json();
  const { to, body:msg } = body;
  const sid = process.env.TWILIO_SID; const token = process.env.TWILIO_TOKEN; const from = process.env.TWILIO_FROM;
  if(!sid || !token || !from) return NextResponse.json({ error:'twilio not configured' }, { status:500 });
  const client = require('twilio')(sid, token);
  try{
    const res = await client.messages.create({ to, from, body: msg });
    return NextResponse.json({ ok:true, sid: res.sid });
  }catch(e){ return NextResponse.json({ error: String(e) }, { status:500 }); }
}
