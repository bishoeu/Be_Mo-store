
import { NextResponse } from 'next/server';
import { dbConnect } from '../../../../lib/mongo';
export async function POST(req: Request){
  const body = await req.json();
  const { title, slug, price_cents, description, images=[] } = body;
  await dbConnect();
  const Product = (await import('../../../../models/Product')).default;
  const exists = await Product.findOne({ slug });
  if(exists) return NextResponse.json({ error:'slug exists' }, { status:400 });
  const p = await Product.create({ title, slug, price_cents, description, images });
  return NextResponse.json(p);
}
