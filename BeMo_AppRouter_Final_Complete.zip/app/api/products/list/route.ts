
import { NextResponse } from 'next/server';
import { dbConnect } from '../../../../lib/mongo';
export async function GET(){
  await dbConnect();
  const Product = (await import('../../../../models/Product')).default;
  const products = await Product.find({}).limit(200).lean();
  return NextResponse.json(products);
}
