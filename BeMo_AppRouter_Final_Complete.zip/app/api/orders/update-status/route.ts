
import { NextResponse } from 'next/server';
import { dbConnect } from '../../../../lib/mongo';
export async function POST(req: Request){
  const body = await req.json();
  const { id, status } = body;
  if(!id || !status) return NextResponse.json({ error:'missing' }, { status:400 });
  await dbConnect();
  const Order = (await import('../../../../models/Order')).default;
  await Order.findByIdAndUpdate(id, { status });
  return NextResponse.json({ ok:true });
}
