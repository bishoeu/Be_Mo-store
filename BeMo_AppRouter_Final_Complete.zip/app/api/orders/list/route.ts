
import { NextResponse } from 'next/server';
import { dbConnect } from '../../../../lib/mongo';
export async function GET(){
  await dbConnect();
  const Order = (await import('../../../../models/Order')).default;
  const orders = await Order.find({}).sort({createdAt:-1}).limit(200).lean();
  return NextResponse.json(orders);
}
