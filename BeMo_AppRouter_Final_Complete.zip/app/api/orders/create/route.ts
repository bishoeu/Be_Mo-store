
import { NextResponse } from 'next/server';
import { dbConnect } from '../../../../lib/mongo';
export async function POST(req: Request){
  const body = await req.json();
  const { merchant_order_id, amount_cents, currency='EGP', billing_data={}, items=[], payment_method='online' } = body;
  await dbConnect();
  const Order = (await import('../../../../models/Order')).default;
  const order = await Order.create({ merchant_order_id, amount_cents, currency, billing_data, items, payment_method, status: payment_method==='cod'?'pending':'created' });
  if(payment_method === 'online'){
    const base = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000';
    try{
      const resp = await fetch(base + '/api/paymob/create-payment', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ amount_cents, merchant_order_id, billing_data, items, currency })});
      const data = await resp.json();
      return NextResponse.json({ order, payment_url: data.payment_url, payment_token: data.payment_token });
    }catch(e:any){
      return NextResponse.json({ error: String(e) }, { status:500 });
    }
  }
  try{ await fetch((process.env.NEXT_PUBLIC_BASE_URL||'') + '/api/notify/sendgrid', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ to: process.env.NOTIFY_EMAIL, subject: 'طلب COD جديد', text: 'Order: '+merchant_order_id }) }); }catch(e){}
  return NextResponse.json({ order });
}
