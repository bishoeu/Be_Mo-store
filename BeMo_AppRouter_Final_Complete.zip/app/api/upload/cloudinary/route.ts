
import { NextResponse } from 'next/server';
import formidable from 'formidable';
import fs from 'fs';
export const config = { api: { bodyParser: false } };
export async function POST(req: Request){
  const cloudName = process.env.CLOUDINARY_CLOUD_NAME;
  const uploadPreset = process.env.CLOUDINARY_UPLOAD_PRESET || 'unsigned_preset';
  if(!cloudName) return NextResponse.json({ error:'cloudinary not configured' }, { status:500 });
  const form = new formidable.IncomingForm();
  return new Promise((resolve)=>{
    form.parse(req as any, async function(err, fields, files){
      if(err) return resolve(NextResponse.json({ error:'parse' }, { status:500 }));
      const file = files.file;
      if(!file) return resolve(NextResponse.json({ error:'no file' }, { status:400 }));
      const data = fs.readFileSync(file.path);
      const base64 = data.toString('base64');
      const url = `https://api.cloudinary.com/v1_1/${cloudName}/image/upload`;
      const payload = new URLSearchParams();
      payload.append('file', 'data:image/jpeg;base64,' + base64);
      payload.append('upload_preset', uploadPreset);
      try{
        const r = await fetch(url, { method:'POST', body: payload });
        const j = await r.json();
        resolve(NextResponse.json(j));
      }catch(e){
        resolve(NextResponse.json({ error: String(e) }, { status:500 }));
      }
    });
  });
}
