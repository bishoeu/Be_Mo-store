
import { NextResponse } from 'next/server';
export async function POST(req: Request){
  const body = await req.json();
  const { amount_cents, merchant_order_id, billing_data, items, currency='EGP' } = body;
  const apiKey = process.env.PAYMOB_API_KEY;
  const integrationId = process.env.PAYMOB_INTEGRATION_ID;
  const iframeId = process.env.PAYMOB_IFRAME_ID;
  if(!apiKey || !integrationId || !iframeId) return NextResponse.json({ error:'paymob not configured' }, { status:500 });
  const auth = await fetch('https://accept.paymob.com/api/auth/tokens', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ api_key: apiKey })});
  const authJson = await auth.json();
  const authToken = authJson.token;
  const orderResp = await fetch('https://accept.paymob.com/api/ecommerce/orders', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ auth_token: authToken, delivery_needed:false, amount_cents, currency, merchant_order_id, items })});
  const orderJson = await orderResp.json();
  const paymobOrderId = orderJson.id;
  const paymentKeyResp = await fetch('https://accept.paymob.com/api/acceptance/payment_keys', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ auth_token: authToken, amount_cents, expiration:3600, order_id: paymobOrderId, billing_data, integration_id: Number(integrationId) })});
  const pk = await paymentKeyResp.json();
  const paymentToken = pk.token;
  const iframeBase = `https://accept.paymob.com/api/acceptance/iframes/${iframeId}`;
  const payment_url = `${iframeBase}?payment_token=${encodeURIComponent(paymentToken)}`;
  return NextResponse.json({ payment_url, payment_token: paymentToken, order_id: paymobOrderId });
}
