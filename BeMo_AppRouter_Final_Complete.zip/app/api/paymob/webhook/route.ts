
import { NextResponse } from 'next/server';
export async function POST(req: Request){
  const payload = await req.json().catch(()=>null);
  try{
    const { dbConnect } = await import('../../../../lib/mongo');
    const Order = (await import('../../../../models/Order')).default;
    await dbConnect();
    const paymobId = payload?.order?.id || payload?.obj?.order?.id;
    const success = payload?.success === true || payload?.obj?.success === true;
    if(paymobId){
      await Order.findOneAndUpdate({ paymob_order_id: String(paymobId) }, { status: success ? 'paid' : 'failed' });
    }
  }catch(e){}
  return NextResponse.json({ ok:true });
}
