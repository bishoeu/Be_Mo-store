
BeMoStore — Complete Next.js App Router project (ready for Vercel)

Steps to deploy:
1. unzip this project and push to a GitHub repo.
2. Import the repo into Vercel (select Next.js App Router).
3. Set environment variables in Vercel (see .env.example).
4. Deploy.

Local dev:
- Copy .env.example to .env.local and fill values.
- npm install
- npm run dev
- Visit http://localhost:3000

Notes:
- Cloudinary uses unsigned preset by default for simplicity; prefer signed uploads in production.
- Paymob integration uses Accept API; set webhooks to /api/paymob/webhook and configure HMAC key.
- Use MongoDB Atlas and set MONGODB_URI.
